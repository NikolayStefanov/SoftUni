import user from "./user.js";
import trek from "./trek.js";
import home from "./home.js";

export default {
    user,
    trek,
    home
};