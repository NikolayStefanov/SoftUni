import user from "./user.js";
import trek from "./trek.js";

export default{
    user,
    trek
}