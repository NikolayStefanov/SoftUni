﻿namespace _5.Comparing_Objects
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class Person : IComparable<Person>
    {
        public Person(int age, string name, string town) 
        {
            this.Age = age;
            this.Name = name;
            this.Town = town;
        }
        public int Age { get; set; }
        public string Name { get; set; }
        public string Town { get; set; }

        public int CompareTo(Person other)
        {
            if (this.Name.CompareTo(other.Name) == 1)
            {
                return 1;
            }
            else if (this.Name.CompareTo(other.Name) == -1)
            {
                return -1;
            }
            else
            {
                if (this.Age.CompareTo(other.Age) == 1)
                {
                    return 1;
                }
                else if (this.Age.CompareTo(other.Age) == -1)
                {
                    return -1;
                }
                else
                {
                    if (this.Town.CompareTo(other.Town)==1)
                    {
                        return 1;
                    }
                    else if (this.Town.CompareTo(other.Town) == -1)
                    {
                        return -1;
                    }
                    else
                    {
                        return 0;
                    }
                }
            }
        }
    }
}
