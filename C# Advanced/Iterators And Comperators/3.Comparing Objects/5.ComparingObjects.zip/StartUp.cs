﻿namespace _5.Comparing_Objects
{
    using System;
    using System.Collections.Generic;

    public class StartUp
    {
        static void Main()
        {
            var people = new List<Person>();
            var input = string.Empty;
            while ((input = Console.ReadLine()) != "END")
            {
                var splittedInput = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                var name = splittedInput[0];
                var age = int.Parse(splittedInput[1]);
                var town = splittedInput[2];
                var person = new Person(age, name, town);
                people.Add(person);
            }
            var indexOfPerson = int.Parse(Console.ReadLine()) - 1;
            var targetPerson = people[indexOfPerson];
            int countOfSamePeople = 1;
            int countOfDiffPeople = 0;
            int totalCount = 0;
            if (indexOfPerson >= 0 && indexOfPerson < people.Count)
            {
                var counter = 0;
                foreach (var person in people)
                {
                    if (targetPerson.CompareTo(person) != 0)
                    {
                        countOfDiffPeople++;
                    }
                    else
                    {
                        if (counter != 0)
                        {
                            countOfSamePeople++;
                        }
                        counter++;
                    }
                    totalCount++;
                }
            }

            if (countOfSamePeople == 1)
            {
                Console.WriteLine("No matches");
            }
            else
            {
                Console.WriteLine($"{countOfSamePeople} {countOfDiffPeople} {totalCount}");
            }
        }
    }
}
