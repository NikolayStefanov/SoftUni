﻿namespace CustomStack
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class StartUp
    {
        static void Main()
        {
            var stack = new MyStack<int>();
            var command = string.Empty;
            while ((command = Console.ReadLine()) != "END")
            {
                command = command.Replace(',', ' ');
                var pushInput = command.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (pushInput[0] == "Push")
                {
                    for (int i = 1; i < pushInput.Length; i++)
                    {
                        stack.Push(int.Parse(pushInput[i]));
                    }
                }
                else if (pushInput[0] == "Pop")
                {
                    stack.Pop();
                }
            }
            foreach (var element in stack)
            {
                Console.WriteLine(element);
            }
            foreach (var element in stack)
            {
                Console.WriteLine(element);
            }
        }
    }
}
