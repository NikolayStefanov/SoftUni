﻿namespace CustomStack
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Text;

    public class MyStack<T> : IEnumerable<T>
    {
        private List<T> theStack;

        private int count;

        public MyStack()
        {
            this.theStack = new List<T>();
            this.Count = 0;
        }
        public int Count
        {
            get { return count; }
            set { count = value; }
        }

        public void Pop()
        {
            if (this.Count == 0)
            {
                Console.WriteLine("No elements");
                return;
            }
            var lastElement = this.theStack[this.Count - 1];
            this.theStack.RemoveAt(this.Count-1);
            this.Count--;
            
        }
        public void Push(T element)
        {
            this.theStack.Add(element);
            this.Count = this.theStack.Count;
        }
        public IEnumerator<T> GetEnumerator()
        {
            for (int i = this.theStack.Count-1; i >= 0; i--)
            {
                yield return this.theStack[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator() => this.GetEnumerator();
    }
}
