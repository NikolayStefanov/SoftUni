﻿namespace _1._ListyIterator
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class StartUp
    {
        static void Main()
        {
            var firstCommand = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            var listOfElements = new List<string>();
            for (int i = 1; i < firstCommand.Length; i++)
            {
                listOfElements.Add(firstCommand[i]);
            }
            var listyIt = new ListyIterator<string>(listOfElements);
            string command = string.Empty;
            while ((command=Console.ReadLine()) != "END")
            {
                if (command == "Move")
                {
                    Console.WriteLine(listyIt.Move()); 
                }
                else if (command == "HasNext")
                {
                    Console.WriteLine(listyIt.HasNext());
                }
                else if (command == "Print")
                {
                    try
                    {
                        listyIt.Print();

                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Invalid Operation!");
                    }
                }
                else if (command == "PrintAll")
                {
                    try
                    {
                        listyIt.PrintAll();
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Invalid Operation!");
                    }
                }
            }

        }
    }
}
