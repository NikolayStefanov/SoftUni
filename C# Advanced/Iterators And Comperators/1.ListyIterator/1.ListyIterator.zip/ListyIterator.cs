﻿namespace _1._ListyIterator
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Text;
    public class ListyIterator<T> : IEnumerable<T>
    {
        private int defoultIndex;
        public ListyIterator(List<T> elements)
        {
            this.SomeElements = new List<T>();
            this.SomeElements = elements;
            this.defoultIndex = 0;
        }
        public List<T> SomeElements { get; set; }

        public bool Move()
        {
            defoultIndex++;
            if (defoultIndex>=0 && defoultIndex < this.SomeElements.Count)
            {
                return true;
            }
            else
            {
                defoultIndex--;
                return false;
            }
        }
        public bool HasNext()
        {
            if (defoultIndex == SomeElements.Count-1)
            {
                return false;
            }
            return true;
        }
        public void Print()
        {
            if (SomeElements.Count == 0)
            {
                throw new Exception("Invalid Operation!");
            }
            else
            {
                Console.WriteLine(SomeElements[defoultIndex]);
            }
        }
        
        public void PrintAll()
        {
            if (SomeElements.Count == 0)
            {
                throw new Exception("Invalid Operation!");
            }
            else
            {
                foreach (var ele in SomeElements)
                {
                    Console.Write(ele + " ");
                }
                Console.WriteLine();
            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            foreach (var ele in SomeElements)
            {
                yield return ele;
            }
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
