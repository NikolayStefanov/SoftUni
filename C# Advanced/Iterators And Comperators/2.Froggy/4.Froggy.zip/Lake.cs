﻿namespace _4.Froggy
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    public class Lake : IEnumerable<int>
    {
        private List<int> evenStones;
        private List<int> oddStones;
        private List<int> allStones;

        public Lake(List<int> stones)
        {
            this.AllStones = new List<int>();
            this.evenStones = new List<int>();
            this.oddStones = new List<int>();
            for (int i = 0; i < stones.Count; i++)
            {
                if (i % 2 != 0)
                {
                    oddStones.Add(stones[i]);
                }
                else
                {
                    evenStones.Add(stones[i]);
                }
            }
            this.AllStones.AddRange(evenStones);
            oddStones.Reverse();
            this.AllStones.AddRange(oddStones);
        }
        public List<int> AllStones
        {
            get { return allStones; }
            set { allStones = value; }
        }

        public IEnumerator<int> GetEnumerator()
        {
            for (int i = 0; i < this.AllStones.Count; i++)
            {
                yield return this.AllStones[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
