﻿namespace _4.Froggy
{
    using System;
    using System.Linq;

    public class StartUp
    {
        static void Main()
        {
            var input = Console.ReadLine().Split(", ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToList();
            var lake = new Lake(input);
            Console.WriteLine(string.Join(", ", lake.AllStones));
        }
    }
}
